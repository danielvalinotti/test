<!DOCTYPE html>
<html>
<head>
<title>Insertar</title>
</head>
<body>
<?php
// Conectando, seleccionando la base de datos
$link = mysql_connect('localhost', 'administrador', '123456')
    or die('No se pudo conectar: ' . mysql_error());
echo 'Conexion exitosa ';
mysql_select_db('administrador') or die('No se pudo seleccionar la base de datos');

//Recoger datos que llegan
   $nombres=$_POST['nombres'];
   $apellidos=$_POST['apellidos'];
   $fecha_cita=$_POST['fecha_cita'];

//Ejecucion de la sentencia SQL
mysql_query("insert into citas (nombres,apellidos,fecha_cita) values ('$nombres','$apellidos','$fecha_cita')");
?>
<h1><div align="center">Registro Insertado</div></h1>
<div align="center"><a href="muestradatos.php">Visualizar el contenido de la tabla</a></div>
<div align="center"><a href="index.php">Inicio</a></div>
</body>
</html>