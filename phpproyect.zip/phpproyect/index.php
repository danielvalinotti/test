<!DOCTYPE html>

<html>
<head>
<title>Citas</title>
</head>
<body>
	<div align="center">
		<h1>Crear una cita</h1>

		<form method="POST" action="inserta.php">
			Nombre<br><input type="text" name="nombres" id="nombres"/><br>
			Apellidos<br><input type="text" name="apellidos" id="apellidos"/><br>
			Fecha<br><input type="text" name="fecha_cita" id="fecha_cita"/><br>
		<input type="submit" value="Insertar" id="insertar"/>
		</form>
		<div align="center"><a href="muestradatos.php">Visualizar el contenido de la tabla</a></div>
	</div>
</body>
</html>