

<html>
<head>
<title>Insertar</title>
</head>
<body>
<?php
// Conectando, seleccionando la base de datos
$link = mysql_connect('localhost', 'administrador', '123456')
    or die('No se pudo conectar: ' . mysql_error());
echo 'Conexion exitosa ';
mysql_select_db('administrador') or die('No se pudo seleccionar la base de datos');

//Recoger datos que llegan
   $id=$_GET['id'];

// Realizar una consulta MySQL
$query = "DELETE FROM citas WHERE id = $id";
$result = mysql_query($query) or die('NO SE BORRO: ' . mysql_error());

// Cerrar la conexión
mysql_close($link);
?>
<h1><div align="center">Registro borrado</div></h1>
<div align="center"><a href="muestradatos.php">Visualizar el contenido de la tabla</a></div>
<div align="center"><a href="index.php">Inicio</a></div>

</body>
</html>