<!DOCTYPE html>
<html>
<head>
<title>Insertar</title>
</head>
<body>
<?php
// Conectando, seleccionando la base de datos
$link = mysql_connect('localhost', 'administrador', '123456')
    or die('No se pudo conectar: ' . mysql_error());
echo 'Conexion exitosa ';
mysql_select_db('administrador') or die('No se pudo seleccionar la base de datos');

// Realizar una consulta MySQL
$query = "SELECT * FROM citas";
$result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());

// Imprimir los resultados en HTML
echo "<form method='get' action='eliminar.php'>\n";
echo "<table style='' border='1' cellpadding='5'>\n";
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
    echo "\t<tr>\n";
	echo "\t\t<td name='id' id='id'>".$line['id']."<input name='id' type='hidden' value='".$line['id']."'/></td>\n";
        echo "\t\t<td name='nombres' id='nombres'>".$line['nombres']."</td>\n";
		echo "\t\t<td name='apellidos' id='apellidos'>".$line['apellidos']."</td>\n";
		echo "\t\t<td name='fecha_cita' id='fecha_cita'>".$line['fecha_cita']."</td>\n";
			
	echo "\t\t<td><input type='submit' value='Eliminar' id='eliminar'/></td>\n";
    echo "\t</tr>\n";
	
}
echo "</table>\n";
echo "</form>\n";
// Liberar resultados
mysql_free_result($result);

// Cerrar la conexión
mysql_close($link);
?>
</body>
</html>